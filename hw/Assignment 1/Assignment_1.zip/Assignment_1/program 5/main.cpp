/* 
 * File:   main.cpp
 * Author: Adam Wayman
 * program 5
 * Created on September 17, 2017, 2:43 PM
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
    //variables
    char character;
    
    //Enter an input on the keyboard 
    cout<<"Enter a keyboard input"<<endl;
    cin>>character;
    cout<<"  "<<character<<character<<character<<endl;
    cout<<" "<<character<<"  "<<character<<endl;
    cout<<character<<endl;
    cout<<character<<endl;
    cout<<character<<endl;
    cout<<character<<endl;
    cout<<character<<endl;
    cout<<" "<<character<<"  "<<character<<endl;
    cout<<"  "<<character<<character<<character<<endl;
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}

