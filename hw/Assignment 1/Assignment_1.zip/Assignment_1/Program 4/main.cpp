/* 
 * File:   main.cpp
 * Author: Adam
 * Purpose: Free Fall program 2
 * Created on September 12, 2017, 7:16 PM
 */

#include <iostream>
using namespace std;


 //Global Constants
    const float GRAVITY=32.174f;//Gravity ft/sec^2
    const float CNVFTMT=3.28f;  //Conversion from feet to meters
 //Execution Begins Here
 int main(int argc, char** argv) {
  //Variable
     float time;//Input value in seconds
     float distFT;//Output value in feet
     float distMT;//Output value in meters
     float gravMT;//Acceleration due to gravity in meters
    //Input
     cout<<"This program calculates the distance traveled in free fall"<<endl;
     cout<<"Input the time in seconds during free fall"<<endl;
     cin>>time;
     //Process or map the inputs to the outputs
     distFT=GRAVITY*time*time/2;
     distMT=distFT/CNVFTMT;
     gravMT=GRAVITY/CNVFTMT;
     //Output
     cout<<"Time in free fall = "<<time<<"(secs)"<<endl;
     cout<<"Distance fallen   = "<<distFT<<"(ft)"<<endl;
     cout<<"Distance fallen   = "<<distMT<<"( meters)"<<endl;
     cout<<"Gravity ->  "<<GRAVITY<<"(ft/sec^2) = ";
     cout<<gravMT<<"(meters/sec^2)"<<endl;
     
   
    return 0;
}