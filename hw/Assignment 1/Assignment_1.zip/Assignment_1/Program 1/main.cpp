/* 
 * File:   main.cpp
 * Author: Adam Wayman
 * Created on August 29, 2017, 11:28 AM
 * Purpose: Savitch Program 1
 */

//System Libraries
#include <iostream>     //input/output stream library
using namespace std;    //Standard Name-space under which system Libraries reside

//User Libraries 

//Global Constants - Not variable only math/science/Conversation constants 

//Function prototypes

//Execution begins here!

int main(int argc, char** argv) {
    //declare variables
    short a,b,c;
    
    //initialize Variables
    a=200;
    b=300;
    
    //input data/variables
   
    
    //Process or map the inputs to the outputs
    c=a+b;
    //display/output all pertinent variables 
    std::cout<<a<<" + "<<b<<" = "<<c<<std::endl;
    
    //exit the program 
      return 0;
}