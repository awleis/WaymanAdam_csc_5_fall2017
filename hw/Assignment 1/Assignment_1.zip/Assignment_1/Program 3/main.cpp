/* 
 * File:   main.cpp
 * Author: Adam
 * Purpose: Coins program 3
 * Created on September 17, 2017, 7:16 PM
 */

#include <iostream>
using namespace std;


 //Global Constants


 //Execution Begins Here
 int main() {
  //Variable
     int quart,//Number of quarters
      dime, //Number of dimes
      nickel,//Number of nickels
      total,// Total cents
      noq,//Number of quarters
      nod,//Number of dimes
      non;//Number of nickels
    //Input
       quart=25;
       dime=10;
       nickel=5;
     
      //Process or map the inputs to the outputs
       cout<<"Number of quarters"<<endl;
       cin>>noq;
       cout<<"Number of Dimes"<<endl;
       cin>>nod;
       cout<<"Number of Nickels"<<endl;                
       cin>>non;
       //Calculation
       total=(quart*noq)+(dime*nod)+(nickel*non);
       cout<<"Total Cents = "<<total<<endl;
       
      
       
     //Output
     
      
        
    return 0;
}