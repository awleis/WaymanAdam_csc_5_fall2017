#include <iostream>
using namespace std;
int main()
{
    int width, height, totalLength;
    cout<<"Hello\n";
    cout<<"Press return after entering a number.\n";
    cout<<"Enter the width of fence:\n";
    cin>>width;
    cout<<"Enter the height of fence:\n";
    cin>>height;
    totalLength=width*height;
    cout<<"If you have ";
    cout<<width;
    cout<<" feet long fence\n";
    cout<<"and ";
    cout<<height;
    cout<<" feet tall fence, then\n";
    cout<<"You have ";
    cout<<totalLength;
    cout<<" feet of fence needed.\n";
    cout<<" Good-bye\n";
     return 0;
}

