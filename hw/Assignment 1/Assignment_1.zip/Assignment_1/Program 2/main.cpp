/* 
 * File:   main.cpp
 * Author: Adam
 * Purpose: Savitch program 2
 * Created on September 12, 2017, 7:16 PM
 */

#include <iostream>
using namespace std;

int main( )
{   
    cout<<"**************************************"<<endl;
    cout<<"     CCC   "<<"   SSSS    "<<"!!"<<endl;
    cout<<"   C     C "<<"  S    S   "<<"!!"<<endl;
    cout<<"  C        "<<" S         "<<"!!"<<endl;
    cout<<" C         "<<"  S        "<<"!!"<<endl;
    cout<<" C         "<<"   SSSS    "<<"!!"<<endl;
    cout<<" C         "<<"       S   "<<"!!"<<endl;
    cout<<"  C        "<<"        S  "<<"!!"<<endl;
    cout<<"   C     C "<<" S     S   "<<"  "<<endl;
    cout<<"     CCC   "<<"   SSSS    "<<"00"<<endl;
    cout<<"**************************************"<<endl;
cout<<"Computer Science is Cool Stuff!!!"<<endl;
    
    return 0;
}