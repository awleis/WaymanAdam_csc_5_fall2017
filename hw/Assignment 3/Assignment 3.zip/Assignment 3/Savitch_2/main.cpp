/* 
 * File:   main.cpp
 * Author: Adam
 *Savitch 2
 * Created on October 10, 2017, 6:17 PM
 */

#include <iostream>
#include <cmath>
#include<math.h>

using namespace std;


int main(int argc, char** argv) {
  //declare variables
    int a,b,c;
    float root1,root2,sqrt,isis,db;
    //input
    cout<<"Enter value for a "<<endl;
    cin>>a;
    cout<<"Enter value for b "<<endl;
    cin>>b;
    cout<<"Enter value for c "<<endl;
    cin>>c;
    //calculation
    //-b +/-√(b2 - 4ac))/2a
   isis=((pow(b,2)-4*a*c));
   sqrt=pow(isis,0.5);
   db=2*a;
   root1=(-b+sqrt)/(db);
   root2=(-b-sqrt)/(db);
    
    
    
    //output
           cout<<"The roots are "<<root1<<"  and  "<<root2<<endl;
   //cout<<isis<<endl;
    
    
    
    
    
    
    
    return 0;
}

