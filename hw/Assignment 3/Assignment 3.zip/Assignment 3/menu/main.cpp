
/* 
 * File:   main.cpp
 * Author: Adam
 *menu
 * Created on October 11, 2017, 7:04 PM
 */

#include <iostream>     //Input/Output Stream Library
#include <stdlib.h>     //Exit function
#include <cmath>
#include <iomanip> 
using namespace std;
//Global Constants - Not variables only Math/Science/Conversion constants
const int THSNDS =1000;
const int HUNDRDS= 100;
const int TENS   =  10;
const int ONES   =   1;

int main( ) {
//Declare Variables
    int choice;
    
    //Input Data/Variables
    cout<<"Choose from the Menu"<<endl;
    cout<<"1. Problem 1"<<endl;
    cout<<"2. Problem 2"<<endl;
    cout<<"3. Problem 3"<<endl;
    cout<<"4. Problem 4"<<endl;
    cout<<"5. Problem 5"<<endl;
    cout<<"6. Problem 6"<<endl;
    cout<<"7. Problem 7"<<endl;
    cout<<"8. Problem 8"<<endl;
    cout<<"9. Problem 9"<<endl;
    cin>>choice;
    
    //Process or map the inputs to the outputs
    switch(choice){
        case 1:{
             //Declare variables
    int tcs,//Time the call started
            loc;//Length of call (minutes)
            
    float rate=0;//cost of the call
  
    
    char day1, day2;
 
    
  
    
    //input
    cout<<"Please enter the time the call started in 24 hour notation "<<endl;
    cin>>tcs;
    
    cout<<"Please enter the duration of the call in minutes "<<endl;
    cin>>loc;
    
    cout<<"Please enter the day of the week one letter at a time. (Mo,Tu,We,Th,Fr,Sa,Su)"<<endl;
    cin>>day1>>day2;
    
    //calculation
//monday
    if ((day1=='M'||day1=='m')&&(day2=='O'||day2=='o'))
    {
        if((tcs>=800)||(tcs<=1800))
     
        rate=(loc*.40) ;
    }
   else
   {
        rate=(loc*.25);
    
   }
    //Tuesday
        if ((day1=='T'||day1=='t')&&(day2=='U'||day2=='u'))
    {
        if((tcs>=800)||(tcs<=1800))
     
        rate=(loc*.40) ;
    }
   else
   {
        rate=(loc*.25);
    
   }
    //Wednesday
        if ((day1=='W'||day1=='w')&&(day2=='E'||day2=='e'))
    {
        if((tcs>=800)||(tcs<=1800))
     
        rate=(loc*.40) ;
    }
   else
   {
        rate=(loc*.25);
    
   }
    //Thursday 
        if ((day1=='T'||day1=='t')&&(day2=='H'||day2=='h'))
    {
        if((tcs>=800)||(tcs<=1800))
     
        rate=(loc*.40) ;
    }
   else
   {
        rate=(loc*.25);
    
   }
    //Friday
        if ((day1=='F'||day1=='f')&&(day2=='R'||day2=='r'))
    {
        if((tcs>=800)||(tcs<=1800))
     
        rate=(loc*.40) ;
    }
   else
   {
        rate=(loc*.25);
    
   }
    //Saturday
        if ((day1=='S'||day1=='s')&&(day2=='A'||day2=='a'))
    {
                 
     rate=(loc*.15);
    
   }
    //Sunday
         if ((day1=='S'||day1=='s')&&(day2=='U'||day2=='u'))
    {
                 
     rate=(loc*.15);
    
   }
    
        
    
    //calculation
    
       //output
    cout<<"The time call started = "<<tcs<<endl;
    
   
    cout<<"The cost of the call is $"<<rate<<endl;
    
            cout<<"You are in Problem 1"<<endl;
            
            break;
        }
        case 2:{
            //declare variables
    int a,b,c;
    float root1,root2,sqrt,isis,db;
    //input
    cout<<"Enter value for a "<<endl;
    cin>>a;
    cout<<"Enter value for b "<<endl;
    cin>>b;
    cout<<"Enter value for c "<<endl;
    cin>>c;
    //calculation
    //-b +/-√(b2 - 4ac))/2a
   isis=((pow(b,2)-4*a*c));
   sqrt=pow(isis,0.5);
   db=2*a;
   root1=(-b+sqrt)/(db);
   root2=(-b-sqrt)/(db);
    
    
    
    //output
           cout<<"The roots are "<<root1<<"  and  "<<root2<<endl;
   //cout<<isis<<endl;
    
            cout<<"You are in Problem 2"<<endl;
            break;
        }
        case 3:{
              //Declare Variables
    unsigned char nThsnds,nHudrds,nTens,nOnes;
    unsigned short number;
    
    //Input Data/Variables
    cout<<"This program converts numbers to Roman Numerals"<<endl;
    cout<<"Type in a number between 1000-3000"<<endl;
    cin>>number;
    if(!(number>=1000&&number<=3000)){
        cout<<"You don't seem to be able to follow directions!"<<endl;
        cout<<"The number you typed = "<<number<<endl;
        cout<<"Good Bye!!!"<<endl;
        exit(EXIT_FAILURE);
    }
    
    //Process or map the inputs to the outputs
    nThsnds=number/THSNDS;
    number%=THSNDS;
    nHudrds=number/HUNDRDS;
    number%=HUNDRDS;
    nTens=number/TENS;
    number%=TENS;
    nOnes=number;//Same as number/ONES;
    //cout<<static_cast<int>(nThsnds)<<" "<<static_cast<int>(nHudrds)
    //    <<" "<<static_cast<int>(nTens)<<" "<<static_cast<int>(nOnes)<<endl;
    
    //Display/Output all pertinent variables
    //Display The Number of 1000's
    switch(nThsnds){
        case 3: cout<<"M";
        case 2: cout<<"M";
        case 1: cout<<"M";
    }
    //Display The Number of 100's
    switch(nHudrds){
        case 9: cout<<"CM";break;
        case 8: cout<<"DCCC";break;
        case 7: cout<<"DCC";break;
        case 6: cout<<"DC";break;
        case 5: cout<<"D";break;
        case 4: cout<<"CD";break;
        case 3: cout<<"C";
        case 2: cout<<"C";
        case 1: cout<<"C";
    }
    //Display The Number of 10's
    switch(nTens){
        case 9: cout<<"XC";break;
        case 8: cout<<"LXXX";break;
        case 7: cout<<"LXX";break;
        case 6: cout<<"LX";break;
        case 5: cout<<"L";break;
        case 4: cout<<"XL";break;
        case 3: cout<<"X";
        case 2: cout<<"X";
        case 1: cout<<"X";
    }
    //Display The Number of 1's
    switch(nOnes){
        case 9: cout<<"IX";break;
        case 8: cout<<"VIII";break;
        case 7: cout<<"VII";break;
        case 6: cout<<"VI";break;
        case 5: cout<<"V";break;
        case 4: cout<<"IV";break;
        case 3: cout<<"I";
        case 2: cout<<"I";
        case 1: cout<<"I";
    }
            cout<<"You are in Problem 3"<<endl;
            break;
        }
        case 4:{
            //declare variables
    int cards,cbr=0,value=0, number;//number of cards(2,3,4,or 5)
    char cval1;
    
            
    //calculation
    cout<<" how many cards do you have?(2,3,4,5) "<<endl;
    cin>>cards;
    cout<<"What are the card values? (2-9,t,j,q,k,a) "<<endl;
     //loop
    for(cbr;cbr<cards;cbr++) {
            cin>>cval1;
  
    if(cval1=='2'){
         number = 2;
         value = value + number;
          
    }
         else if(cval1=='3'){
        number = 3;
         value = value + number;
    }
        
            else if(cval1=='4'){
                number=4;
              value = value + number;     
            }
            else if(cval1=='5'){
                number=5;
              value = value + number; 
            
            }
            
            else if(cval1=='6'){
                number=6;
              value = value + number; 
            }
            
            else if(cval1=='7'){
                number=7;
              value = value + number; 
            }
            else if(cval1=='8'){
                number=8;
              value = value + number; 
            }
            else if(cval1=='9'){
                number=9;
              value = value + number; 
            }
            else if(cval1=='t'||cval1=='j'||cval1=='q'||cval1=='k'||cval1=='T'||cval1=='J'||cval1=='Q'||cval1=='K'){
                number=10;
              value = value + number; 
            }
            else{
                   number=11;
                    value = value + number; 
                
               if(value>21 ){
                    
                    value=value-10;
            
               }
            
            
            
            }
            
                          
                                               
            }
                                                                                   
                    
              
    //output
    
    if(value>21)
         cout<<"busted"<<endl;  
    if(value=21)
         cout<<"A god among men"<<endl; 
    cout<<value;
            cout<<"You are in Problem 4"<<endl;
            break;
        }
        case 5:{
            //declare
    float loan;
    float inrate; //interest rate
    float intrst;//Interest payment//166
    float monpay; //monthly payment- 1/20 of original loan amount (1000)
    float balrem;//balance remaining to pay off loan
    float totint;//total interest paid over the life of the loan
    float anpol;//annualized percentage of original loan balance
    float greg;//20000
    float bob;//1000
    float larry;//833
    float chris;
    float cat;
    float i=0;
    float bsub;//remainder amount
    //input
    cout<<"Please enter the loan amount "<<endl;
    cin>>loan;
    cout<<"Please enter the interest rate "<<endl;
    cin>>inrate;
    
    //calculation
    monpay=loan*.05;//1000
    greg=loan;//20000
    bob=monpay;//1000        
    intrst=(inrate*greg)/12;//166
   larry=bob-intrst;   //833    
   cat=greg-larry;//subtracting balance //19,166.67
   
   //cout<<cat;
   //cout<<intrst;
    
    
    //loop
   while(cat>0){
       chris=(cat*inrate)/12;//159.72 
       i=i+chris;
      bsub=bob-chris; 
      cat=cat-bsub;
      cout<<"The balance of the loan is  "<<cat<<endl;
      cout<<"The monthly payment to the loan " <<bsub<<endl;
     cout<<"The monthly payment to the interest " <<chris<<endl;
      
   }
   
    
   totint=i+intrst;
   anpol=totint;
     //Output
     
     cout<<"The total interest paid is "<<totint<<endl;
            cout<<"You are in Problem 5"<<endl;
            break;
        }
        case 6:{
            //Declare Variables
    int fi,fim1,fim2,counter;
    int wtCrud =10;//5 lbs of crud to start
    int deltDys=5;//5 Days between increments
    
    //Initialize Variables
    fim1=fim2=1; //Initialize the sequence
    counter=1;   //Start with 3rd term in the sequence
    
    //Table Header
    cout<<"  Sequence   Crud Wt    N Days"<<endl;
    
    //Process or map the inputs to the outputs
    //First Row
    cout<<setw(10)<<fim2<<setw(10)<<wtCrud*fim2
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Second Row
    cout<<setw(10)<<fim1<<setw(10)<<wtCrud*fim1
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Third Row
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Fourth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
   
    
    //Display/Output all pertinent variables
    
    //Exit the program
            cout<<"You are in Problem 6"<<endl;
            break;
        }
        case 7:{
             //Declare Variables
    float etox=1,x;
    int counter=1,fact=1;

    //Input Data/Variables
    cout<<"This program approximates e^x"<<endl;
    cout<<"Input a real from 0 to 2"<<endl;
    cin>>x;
    
    //Process or map the inputs to the outputs
    cout<<"e^"<<x<<" with "<<counter<<" term  = "<<etox<<endl;
    fact*=counter;
    etox+=(pow(x,counter++)/fact);
    
    cout<<"e^"<<x<<" with "<<counter<<" term  = "<<etox<<endl;
    fact*=counter;
    etox+=(pow(x,counter++)/fact);
    
    cout<<"e^"<<x<<" with "<<counter<<" term  = "<<etox<<endl;
    fact*=counter;
    etox+=(pow(x,counter++)/fact);
    
    cout<<"e^"<<x<<" with "<<counter<<" term  = "<<etox<<endl;
    fact*=counter;
    etox+=(pow(x,counter++)/fact);
    
    cout<<"e^"<<x<<" with "<<counter<<" term  = "<<etox<<endl;
    fact*=counter;
    etox+=(pow(x,counter++)/fact);
    
    cout<<"e^"<<x<<" with "<<counter<<" term  = "<<etox<<endl;
    fact*=counter;
    etox+=(pow(x,counter++)/fact);
    
    cout<<"e^"<<x<<" with "<<counter<<" term  = "<<etox<<endl;
    fact*=counter;
    etox+=(pow(x,counter++)/fact);
    
    cout<<"e^"<<x<<" with "<<counter<<" term  = "<<etox<<endl;
    fact*=counter;
    etox+=(pow(x,counter++)/fact);
    
    cout<<"e^"<<x<<" with "<<counter<<" term  = "<<etox<<endl;
    fact*=counter;
    etox+=(pow(x,counter++)/fact);
 
    cout<<"e^"<<x<<" with "<<counter<<" term  = "<<etox<<endl;
    cout<<"e^"<<x<<" with Library function = "<<exp(x)<<endl;
    
            cout<<"You are in Problem 7"<<endl;
            break;
        }
        case 8:{
            //variables
    int n;// Number of terms in the approximation of value of pi    
   float  pi=0;//pi
          
    
    
    //Input
cout<<"Please enter the number of terms you wish to approximate"<<endl;
cin>>n;
//calculation

//loop
for(int chris=0; chris<n; chris++){

  pi+= pow(-1,chris)/ ((2*chris)+1);

}   
pi=pi*4;
    //output
cout<<"The approximation is = "<<pi<<endl;
    
    
            cout<<"You are in Problem 8"<<endl;
            break;
        }
        case 9:{
            
            cout<<"You are in Problem 9"<<endl;
            break;
        }
        default:{
            cout<<"You seem to have problems with instructions"<<endl;
            cout<<"You are unworthy of running this code"<<endl;
        }
    }
    return 0;
}

