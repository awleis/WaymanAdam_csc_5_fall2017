/* 
 * File:   main.cpp
 * Author: Adam Wayman
 *Savitch 8
 * Created on October 10, 2017, 6:52 PM
 */

#include <iostream>
#include <cmath>
#include <math.h>

using namespace std;

/*
 * 
 */
int main()
{
//variables
    int n;// Number of terms in the approximation of value of pi    
   float  pi=0;//pi
          
    
    
    //Input
cout<<"Please enter the number of terms you wish to approximate"<<endl;
cin>>n;
//calculation

//loop
for(int chris=0; chris<n; chris++){

  pi+= pow(-1,chris)/ ((2*chris)+1);

}   
pi=pi*4;
    //output
cout<<"The approximation is = "<<pi<<endl;
    
    
    
    
    
    return 0;
}

