/* 
 * File:   main.cpp
 * Author: Adam
 *Savitch 1
 * Created on October 10, 2017, 6:17 PM
 */

#include <iostream>
#include <string>

using namespace std;



int main() {
  //Declare variables
    int tcs,//Time the call started
            loc;//Length of call (minutes)
            
    float rate=0;//cost of the call
  
    
    char day1, day2;
 
    
  
    
    //input
    cout<<"Please enter the time the call started in 24 hour notation "<<endl;
    cin>>tcs;
    
    cout<<"Please enter the duration of the call in minutes "<<endl;
    cin>>loc;
    
    cout<<"Please enter the day of the week one letter at a time. (Mo,Tu,We,Th,Fr,Sa,Su)"<<endl;
    cin>>day1>>day2;
    
    //calculation
//monday
    if ((day1=='M'||day1=='m')&&(day2=='O'||day2=='o'))
    {
        if((tcs>=800)||(tcs<=1800))
     
        rate=(loc*.40) ;
    }
   else
   {
        rate=(loc*.25);
    
   }
    //Tuesday
        if ((day1=='T'||day1=='t')&&(day2=='U'||day2=='u'))
    {
        if((tcs>=800)||(tcs<=1800))
     
        rate=(loc*.40) ;
    }
   else
   {
        rate=(loc*.25);
    
   }
    //Wednesday
        if ((day1=='W'||day1=='w')&&(day2=='E'||day2=='e'))
    {
        if((tcs>=800)||(tcs<=1800))
     
        rate=(loc*.40) ;
    }
   else
   {
        rate=(loc*.25);
    
   }
    //Thursday 
        if ((day1=='T'||day1=='t')&&(day2=='H'||day2=='h'))
    {
        if((tcs>=800)||(tcs<=1800))
     
        rate=(loc*.40) ;
    }
   else
   {
        rate=(loc*.25);
    
   }
    //Friday
        if ((day1=='F'||day1=='f')&&(day2=='R'||day2=='r'))
    {
        if((tcs>=800)||(tcs<=1800))
     
        rate=(loc*.40) ;
    }
   else
   {
        rate=(loc*.25);
    
   }
    //Saturday
        if ((day1=='S'||day1=='s')&&(day2=='A'||day2=='a'))
    {
                 
     rate=(loc*.15);
    
   }
    //Sunday
         if ((day1=='S'||day1=='s')&&(day2=='U'||day2=='u'))
    {
                 
     rate=(loc*.15);
    
   }
    
        
    
    //calculation
    
       //output
    cout<<"The time call started = "<<tcs<<endl;
    
   
    cout<<"The cost of the call is $"<<rate<<endl;
    
    
    
    
    
    
    
    
    
    
    return 0;
}

