/* 
 * File:   main.cpp
 * Author: Adam Wayman
 *Savitch 11 genie
 * Created on October 10, 2017, 6:52 PM
 */

#include <iostream>
#include <cmath>
#include <math.h>
#include <stdlib.h>

using namespace std;
//global constants




int main()
{
//variables
    int tempL,//Temperature
            tempLL,
            dtemp,//desired temperature
            nHudrds,
            nTens,
            nOnes,
            hr,//Hundred remainder
            tr;//tens remainder
            
                          
    //Input
cout<<"Please enter the desired temperature between 0 and 999 "<<endl;
cin>>dtemp;

if ((dtemp > 999)||dtemp < 0){
    cout<<"Error! Please enter a number between 0 and 999. "<<endl;
exit(EXIT_FAILURE);
}
tempL=dtemp;
tempLL=tempL;
//calculation
nHudrds=dtemp/100;
hr=dtemp%100;
  nTens=hr/10;
  tr=hr%10;
  //hundred
      
      
 do{
      dtemp++;
      tempLL--;

  }
  while(nHudrds == 1 || nHudrds == 4 || nHudrds == 7||nTens==1 ||nTens==4||nTens==7||tr==1||tr==4||tr==7);
 
 
  
  /*if(dtemp==200||dtemp==300||dtemp==500||dtemp==600||dtemp==800||dtemp==900)break;
  }
  
  while(nHudrds == 1 || nHudrds == 4 || nHudrds == 7){
      tempL--;
      
  if(tempL==99||tempL==200||tempL==300||tempL==500||tempL==600||tempL==800||tempL==900)break;
  }
  //Tens
  while(nTens == 1 || nTens == 4 || nTens == 7){
      dtemp++;
      
  if(dtemp==200||dtemp==300||dtemp==500||dtemp==600||dtemp==800||dtemp==900)break;
  }
  
  while(nTens == 1 || nTens == 4 || nTens == 7){
      tempL--;
      
  if(tempL==99||tempL==200||tempL==300||tempL==500||tempL==600||tempL==800||tempL==900)break;
  }
  
 */ 
  
  
  
  
  
  
  cout<<"our big boy temp is = "<<dtemp<<endl;
  cout<<tempLL;
//loop




    //output

    
    
    
    
    
    return 0;
}

