/* 
 * File:   main.cpp
 * Author: Adam
 *Savitch 5
 * Created on October 11, 2017, 5:01 PM
 */

#include <iostream>
#include <cmath>

using namespace std;


int main(int argc, char** argv) {
//declare
    float loan;
    float inrate; //interest rate
    float intrst;//Interest payment//166
    float monpay; //monthly payment- 1/20 of original loan amount (1000)
    float balrem;//balance remaining to pay off loan
    float totint;//total interest paid over the life of the loan
    float anpol;//annualized percentage of original loan balance
    float greg;//20000
    float bob;//1000
    float larry;//833
    float chris;
    float cat;
    float i=0;
    float bsub;//remainder amount
    //input
    cout<<"Please enter the loan amount "<<endl;
    cin>>loan;
    cout<<"Please enter the interest rate "<<endl;
    cin>>inrate;
    
    //calculation
    monpay=loan*.05;//1000
    greg=loan;//20000
    bob=monpay;//1000        
    intrst=(inrate*greg)/12;//166
   larry=bob-intrst;   //833    
   cat=greg-larry;//subtracting balance //19,166.67
   
   //cout<<cat;
   //cout<<intrst;
    
    
    //loop
   while(cat>0){
       chris=(cat*inrate)/12;//159.72 
       i=i+chris;
      bsub=bob-chris; 
      cat=cat-bsub;
      cout<<"The balance of the loan is  "<<cat<<endl;
      cout<<"The monthly payment to the loan " <<bsub<<endl;
     cout<<"The monthly payment to the interest " <<chris<<endl;
      
   }
   while()
    
   totint=i+intrst;
   anpol=totint
     //Output
     
     cout<<"The total interest paid is "<<totint<<endl;
    return 0;
    
}

