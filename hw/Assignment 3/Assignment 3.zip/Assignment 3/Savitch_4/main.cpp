/* 
 * File:   main.cpp
 * Author: Adam
 *Savitch 4
 * Created on October 10, 2017, 6:17 PM
 */

#include <iostream>
#include <cmath>
#include<math.h>

using namespace std;


int main(int argc, char** argv) {
  //declare variables
    int cards,cbr=0,value=0, number;//number of cards(2,3,4,or 5)
    char cval1;
    
            
    //calculation
    cout<<" how many cards do you have?(2,3,4,5) "<<endl;
    cin>>cards;
    cout<<"What are the card values? (2-9,t,j,q,k,a) "<<endl;
     //loop
    for(cbr;cbr<cards;cbr++) {
            cin>>cval1;
  
    if(cval1=='2'){
         number = 2;
         value = value + number;
          
    }
         else if(cval1=='3'){
        number = 3;
         value = value + number;
    }
        
            else if(cval1=='4'){
                number=4;
              value = value + number;     
            }
            else if(cval1=='5'){
                number=5;
              value = value + number; 
            
            }
            
            else if(cval1=='6'){
                number=6;
              value = value + number; 
            }
            
            else if(cval1=='7'){
                number=7;
              value = value + number; 
            }
            else if(cval1=='8'){
                number=8;
              value = value + number; 
            }
            else if(cval1=='9'){
                number=9;
              value = value + number; 
            }
            else if(cval1=='t'||cval1=='j'||cval1=='q'||cval1=='k'||cval1=='T'||cval1=='J'||cval1=='Q'||cval1=='K'){
                number=10;
              value = value + number; 
            }
            else{
                   number=11;
                    value = value + number; 
                
               if(value>21 ){
                    
                    value=value-10;
            
               }
            
            
            
            }
            
                          
                                               
            }
                                                                                   
                    
              
    //output
    
    if(value>21)
         cout<<"busted"<<endl;  
    if(value=21)
         cout<<"A god among men"<<endl; 
    cout<<value;
   return 0;
}

