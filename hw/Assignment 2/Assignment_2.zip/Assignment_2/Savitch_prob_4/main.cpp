/* 
 * File:   main.cpp
 * Author: Adam
 * savitch problem 4
 * Created on September 26, 2017, 1:24 PM
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
//Declare Variables 
    float cntr,//consumer needs to receive
            i,//interest rate
            dLm,//duration of loan in months
            fval,//face value
            monp,//monthly payment
            time;//time
    int const year = 12;
    char ans;
    
    do
    {
   
             
            //Process or map the inputs to the outputs
    cout<<"Enter the amount of money needed ";
    cin>>cntr;
    cout<<"Enter the interest rate ";
    cin>>i;
    cout<<"Enter the duration of the loan in months ";
    cin>>dLm;
    cout<<endl;
    
    time=dLm/year;
    fval=(1+cntr)/(i*time);
    monp=fval/dLm;
            
    cout<<"The face value is "<<fval<<endl;
    cout<<"The monthly payment is "<<monp<<endl;
    cout<<"run again?"<<endl;
    cin>>ans;
    }while(ans=='y'||ans=='y');
            
            
    
                                                                         
                     return 0;
}

