/* 
 * File:   main.cpp
 * Author: Adam
 * savitch problem 13
 * Created on September 26, 2017, 1:24 PM
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
//Declare Variables 
    float wt,//weight in pounds
            ht,//height in inches
            age,//age in years
            m,//male
            f,//female
            chbr,//chocolate bars
            bmr,//basal metabolic rate
        char gndr;//Gender
    
      //Process or map the inputs to the outputs
    cout<<"Enter your weight in pounds. ";
    cin>>wt;
    cout<<"Enter your Height in inches. ";
    cin>>ht;
    cout<<"Enter your age in years. ";
    cin>>age;
    cout<<"Enter your sex either m for male or f for female. ";
    cin>>gndr;
     
     
          if(gndr=='m')
     {
         bmr=655+(4.3*wt)+(4.7*ht)-(4.7*age);
    cout<<bmr<<" calories needed to maintain weight";
     }
          else 
          {
         
    bmr=66+(6.3*wt)+(12.9*ht)-(6.8*age); 
     
    cout<<bmr<<" calories needed to maintain weight. ";
}
            
    chbr=230;
    cout<<" So you can eat "<<(bmr/chbr)<<" chocolate bars "<<endl;       
                 
                return 0;
}

