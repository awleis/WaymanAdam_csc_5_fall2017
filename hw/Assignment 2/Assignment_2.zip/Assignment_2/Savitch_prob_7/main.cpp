/* 
 * File:   main.cpp
 * Author: Adam
 * savitch problem 7
 * Created on September 26, 2017, 1:24 PM
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
//Declare Variables 
    float ec,//Expected cost
            noy,//Number of years from now that the item will be purchased
            coi,//cost of item
            roi,//Rate of inflation
            roie,//rate
            coer,//dummy
            coin,//cost to be added to new item 
            roin;//rate of inflation new
    
    
    //input
    cout<<"What is the cost of the item ? ";
            cin>>coi;
            cout<<"How many years from now will that item be purchased ? ";
            cin>>noy;
            cout<<"What is the rate of inflation ? (as a percentage) ";
            cin>>roi;
            
            //coer
            coer=1;
            roie=0;
            
            
            
    //loop
            while(coer<=noy)
            {
               roie=roie+roi;
               coer=coer+1;
                
                                            
                              
            }
            
    //calculation 
   
          
                roin=(roie/100);//decimal of rate of inflation after n years
                coin=roin*coi;//price to be added to original
                ec=coin+coi;
                
                cout<<"The Price after n years = "<<ec<<endl;
             
        
      return 0;
}

