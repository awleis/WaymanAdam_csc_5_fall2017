/* 
 * File:   main.cpp
 * Author: Adam
 * savitch problem 2
 * Created on September 26, 2017, 1:24 PM
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
//Declare Variables 
    const float pinc = 0.076;//Pay increase 7.6%
    const int nom = 12; ;//the number of months 
    float rto,//retroactive pay
            msal,//monthly salary
            annsal,//Annual salary
            oldsal;//old salary 
    char ans;
    
    do
    {
        
    //Process or map the inputs to the outputs
    cout<<"Enter your previous Annual salary"<<endl;
    cin>>oldsal;
    annsal=(oldsal*pinc)+oldsal;
    msal=annsal/nom;
    rto=(oldsal/2)*pinc;
    cout<<endl;
    cout<<"The retroactive pay is $";
    cout<<rto<<endl;
    cout<<"The new Annual pay is $";
            cout<<annsal<<endl;
    cout<<"The new monthly salary is $";
            cout<<msal<<endl;
            cout<<"Run again?"<<endl;
            cin>>ans;
}while(ans=='y'||'y'==ans);
            
            
    
                                                                         
                     return 0;
}

