/* 
 * File:   main.cpp
 * Author: Adam Wayman
 * Created on september, 2017, 11:20AM
 * Purpose:  Savitch ch 2 prob 1
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
const float conv=1/453.5;
//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float hWt,//Human Weight
            mM,//Mouse mass
            sM,//Sweetener mass
            cnlv,//Concentration level of sweetener in coke
            cM;//Coke mass = 350grams
    float can;//Cans of coke
                  
   //Input or initialize values Here
    hWt=125;
    mM=35;
    sM=5;
    cnlv=.001;
    cM=350;
    
    
    //Process/Calculations Here
    can=hWt*(sM/mM)/(cM*cnlv*conv);
    //Output Located Here
    cout<<"The amount of cans that will kill me = "<<can<<endl;
    
    //Exit
    return 0;
}

