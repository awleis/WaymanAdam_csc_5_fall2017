/* 
 * File:   main.cpp
 * Author: Adam
 * savitch problem 9
 * Created on September 26, 2017, 1:24 PM
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
//Declare Variables 
 int x,sum=0,sumPos=0,sumNeg=0;
    
    //Input Data/Variables
    cout<<"Sum 10 Numbers + or - and get the Pos or Neg Sum"<<endl;
    cout<<"Input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
    cout<<"Input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);

    cout<<"Input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
    cout<<"Input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
    cout<<"Input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
    cout<<"Input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
    cout<<"Input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
    cout<<"Input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
    cout<<"Input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
    cout<<"Input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
    //Calculate total
    sum=sumPos+sumNeg;
    
    //Display/Output all pertinent variables
    cout<<"The positive sum = "<<sumPos<<endl;
    cout<<"The negative sum = "<<sumNeg<<endl;
    cout<<"The total sum =    "<<sum<<endl;   
                                    
               
      return 0;
}

