/* 
 * File:   main.cpp
 * Author: Adam
 * savitch problem 11
 * Created on September 26, 2017, 1:24 PM
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
//Declare Variables 
    float tpp,//total points possible
            tpe,//total points earned
            p,//percent
            n,//exercises
            sc,//scores received
            tt,//total
            sum,//sum of sc
            sumt,//sum total
            a;//dummy
            
    //input
    a=1;
     sum=0; 
     sumt=0;
            
            
    //calculation 
   cout<<"How many exercises to input? ";
   cin>>n;
     while(a<=n)
              {
          
         
    cout<<"Score received for exercise "<<a<<" : ";
    cin>>sc;
    sum=sum+sc;
    cout<<"Total points possible for exercise "<<a<<" : ";
    cin>>tpp;
    sumt=sumt+tpp;
    
               a=a+1;
               
     }
               cout<<"Your total is "<<sum<<" out of "<<sumt<<",  or "<<(sum/sumt)*100<<" % "<<endl;
             
             
         
      return 0;
}

