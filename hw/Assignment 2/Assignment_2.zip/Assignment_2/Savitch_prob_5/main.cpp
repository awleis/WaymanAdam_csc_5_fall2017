/* 
 * File:   main.cpp
 * Author: Adam
 * savitch problem 5
 * Created on September 26, 2017, 1:24 PM
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
//Declare Variables 
    float mrc,//Maximum room capacity
            nop;//Number of people
            
             
            //Process or map the inputs to the outputs
    cout<<"Enter the Maximum room capacity ";
    cin>>mrc;
    cout<<"Enter the number of people that are attending the meeting ";
    cin>>nop;
    cout<<endl;
    if(nop<=mrc)
        cout<<"Legal";
    else if(nop>mrc)
    {
        cout<<"The meeting cannot be held as planned due to fire regulations. "<<endl;
        cout<<"Please exclude "<<(nop-mrc)<<" from the room"<<endl;        
    }
    
            
            
    
                                                                         
                     return 0;
}

