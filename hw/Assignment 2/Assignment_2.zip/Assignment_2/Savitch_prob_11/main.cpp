/* 
 * File:   main.cpp
 * Author: Adam
 * savitch problem 11
 * Created on September 26, 2017, 1:24 PM
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
//Declare Variables 
    float velo,//temperature
    temps,//starting temperature
    tempe;//ending temperature
      //Process or map the inputs to the outputs
    cout<<"Enter the Starting Temperature (Celsius) ";
    cin>>temps;
    cout<<"Enter the ending temperature (Celsius) ";
    cin>>tempe;
    //calculation 
    while(temps<=tempe)
        
    {
     velo=331.3+.61*temps;
    
             //output
     cout <<"At "<<temps;
     cout<<" degrees Celsius the velocity of sound is "<<velo<<" m/s "<<endl;
      temps=temps+1;
     
             
             
             
             
             
    }          
                return 0;
}

